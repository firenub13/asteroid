import greenfoot.*;

public class UFOsmall extends Actor
{
   
    GreenfootImage myImage;
    int rotation = 90;
    int down;
    int back;
    int repeats;
    int rotateFrame = 0;
    int set = 0;
    int cooldown = Greenfoot.getRandomNumber(25)+15;
    GreenfootSound Swhirr = new GreenfootSound("saucerSmall.wav");
    public UFOsmall(){
        myImage = new GreenfootImage(41, 26);
        setImage(myImage);
        myImage.setColor(Color.WHITE);
        //create a list of x points
        int[] xPoints = {0, 5, 35, 40, 0, 8, 32, 40, 32, 25, 15, 8};
        //create a list of y points
        int[] yPoints = {16, 25, 25, 16, 16, 9, 9, 16, 9, 0, 0, 9};
        //use drawPolygon to draw the costume of the asteroid
        myImage.drawPolygon(xPoints, yPoints, 12);
    }
 
    //UFO moves - has a random chance of moving up and down
    public void act() 
    {
           rotateFrame--;
        cooldown--;
        setRotation(0);
           if (set != 1){
            if (getY()<0){
                down = 1;
            }else if(getY()>800){
                down = 0;
            }else{
                down = 2;
            }
            if (getX()<0){
                back = 0;
            }else if(getX()>1000){
                back = 1;
            }else{
                back = 2;
            }
            set = 1;
        }
        
        if(rotateFrame<1){
        if(down == 1){
            rotation = Greenfoot.getRandomNumber(180)+90;
        }else if (down == 0){
            rotation = (Greenfoot.getRandomNumber(180)+90)*-1;
        }else{
            if (back == 1){
                rotation = Greenfoot.getRandomNumber(180)*-1;
            }else{
                rotation = Greenfoot.getRandomNumber(180);
            }
        }
        rotateFrame = Greenfoot.getRandomNumber(250)+50;
    }
        setRotation(rotation);
        move(5);
        Swhirr.play();
        setRotation(0);
        if (cooldown<1){
        getWorld().addObject(new UFOBullet(), getX(), getY());
        Greenfoot.playSound("fire.mp3");
        cooldown = Greenfoot.getRandomNumber(50)+15;
    }
    
        if(getX()<-39){
            getWorld().removeObject(this);
        }else if (getX()>1039){
            getWorld().removeObject(this);
        }else if (getY()<-39){
            getWorld().removeObject(this);
        }else if (getY()>839){
            getWorld().removeObject(this);
        }else if(isTouching(ShipBullet.class)){
            removeTouching(ShipBullet.class);
            Greenfoot.playSound("bangSmall.wav");
            getWorld().addObject(new DebrisDot(), getX(), getY());
            getWorld().addObject(new DebrisDot(), getX(), getY());
            getWorld().addObject(new DebrisDot(), getX(), getY());
            getWorld().addObject(new DebrisDot(), getX(), getY());
            getWorld().addObject(new DebrisLine(), getX(), getY());
            getWorld().addObject(new DebrisLine(), getX(), getY());
            SpaceWorld.score += 1000;
            getWorld().removeObject(this);
        }
    }
    
}    


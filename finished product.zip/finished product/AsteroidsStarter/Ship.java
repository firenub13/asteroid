import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

import java.util.List;

public class Ship extends SmoothMover
{
    GreenfootImage myImage;
    GreenfootImage myImageFire;
    GreenfootImage nada;
    int frame = 0;
    int shootCooldown;
    int damageCooldown;
    int damageSprite;
    GreenfootSound thrust = new GreenfootSound("thrust.wav");
    GreenfootSound fthrust = new GreenfootSound("fthrust.wav");
    public Ship(){
        myImage = new GreenfootImage(50, 30);
        setImage(myImage);
        myImage.setColor(Color.WHITE);
        myImage.drawLine(5, 0, 50, 15);
        myImage.drawLine(5, 29, 50, 15);
        myImage.drawLine(11, 3, 11, 26);
        
        myImageFire = new GreenfootImage(50, 30);
        setImage(myImageFire);
        myImageFire.setColor(Color.WHITE);
        myImageFire.drawLine(5, 0, 50, 15);
        myImageFire.drawLine(5, 29, 50, 15);
        myImageFire.drawLine(11, 3, 11, 26);
        myImageFire.drawLine(11, 9, 0, 15);
        myImageFire.drawLine(11, 20, 0, 15);
        
        nada = new GreenfootImage(50, 30);
        
        turn(-90);
        
    }
    
    public void act() 
    {
        if (SpaceWorld.dead == 0){
        shootCooldown--;
        System.out.println(getSpeed());
        move();
        if(Greenfoot.isKeyDown("left")||Greenfoot.isKeyDown("A")){
          turn(-4);
        }
        if(Greenfoot.isKeyDown("right")||Greenfoot.isKeyDown("D")){
          turn(4);
        }
        
        if(Greenfoot.isKeyDown("shift")){
            SpaceWorld.speed = 4;
        }else{
            SpaceWorld.speed = 1;
        }
        
        if((Greenfoot.isKeyDown("up")||Greenfoot.isKeyDown("W"))&&SpaceWorld.speeding!=1){
            if(SpaceWorld.speed>1){
                fthrust.play();
            }else{
                thrust.play();
        }
            if (frame<4){
            frame++;
            }else{
            frame = 0;
            }
            if (frame<3){
                setImage(myImageFire);
            }else{
                setImage(myImage);
            }
            Vector drift = new Vector(getRotation(), 0.1*SpaceWorld.speed);
            addForce(drift);
        }
        else{
         accelerate(0.97);
         setImage(myImage);
        }
        
        if(damageCooldown<1){
        if(isTouching(AsteroidLarge.class)){
            SpaceWorld.health--;
            damageCooldown = 100;
        }else if (isTouching(AsteroidMedium.class)){
            SpaceWorld.health--;
            damageCooldown = 100;
        }else if (isTouching(AsteroidSmall.class)){
            SpaceWorld.health--;
            damageCooldown = 100;
        }
    }
        
        if(damageCooldown>0){
            damageCooldown--;
            damageSprite--;
            if(damageSprite<1){
                damageSprite = 10;
            }else if(damageSprite<6){
                setImage(nada);
            }
        }
        
        //add a ShipBullet when the spacebar is pressed
            //use the getRotation() method when calling the ShipBullet constructor
        if(Greenfoot.isKeyDown("space")){
            if(shootCooldown<1){
              getWorld().addObject(new ShipBullet(getRotation()), getX(), getY());
              Greenfoot.playSound("fire.mp3");
              shootCooldown = 15;
            }
        }
        
        if(SpaceWorld.health < 1){
            setImage(nada);
            SpaceWorld.dead = 1;
            getWorld().addObject(new DebrisLine(), getX(), getY());
            getWorld().addObject(new DebrisLine(), getX(), getY());
            getWorld().addObject(new DebrisLine(), getX(), getY());
        }
    }
       
     }    
}

import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class health here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class health extends Actor
{
    GreenfootImage zero;
    GreenfootImage one;
    GreenfootImage two;
    GreenfootImage three;
    int cooldown = 150;
    int last = 2;
    
    public health(){
        zero = new GreenfootImage(50, 90);
        one = new GreenfootImage(50, 90);
        setImage(one);
        one.setColor(Color.WHITE);
        one.drawLine(5, 0, 50, 15);
        one.drawLine(5, 29, 50, 15);
        one.drawLine(11, 3, 11, 26);
        two = new GreenfootImage(50, 90);
        setImage(two);
        two.setColor(Color.WHITE);
        two.drawLine(5, 0, 50, 15);
        two.drawLine(5, 29, 50, 15);
        two.drawLine(11, 3, 11, 26);
        //2
        two.drawLine(5, 30, 50, 45);
        two.drawLine(5, 59, 50, 45);
        two.drawLine(11, 33, 11, 56);
        three = new GreenfootImage(50, 90);
        setImage(three);
        three.setColor(Color.WHITE);
        three.drawLine(5, 0, 50, 15);
        three.drawLine(5, 29, 50, 15);
        three.drawLine(11, 3, 11, 26);
        //2
        three.drawLine(5, 30, 50, 45);
        three.drawLine(5, 59, 50, 45);
        three.drawLine(11, 33, 11, 56);
        //3
        three.drawLine(5, 60, 50, 75);
        three.drawLine(5, 89, 50, 75);
        three.drawLine(11, 63, 11, 86);
        setRotation(270);
    }
    /**
     * Act - do whatever the health wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    public void act()
    {
        // Add your action code here.
        if (SpaceWorld.health>0){
        cooldown--;
    }
        if (cooldown<1){
            if(last==1){
                Greenfoot.playSound("beat2.wav");
                last = 2;
            }else if(last==2){
                Greenfoot.playSound("beat1.wav");
                last = 1;
            }
            if (SpaceWorld.health > 2){
               cooldown = 75; 
            }else if (SpaceWorld.health == 2){
                cooldown = 50;
            }else{
                cooldown = 30;
            }
        }
        if (SpaceWorld.health > 2){
            setImage(three);
        }else if (SpaceWorld.health == 2){
            setImage(two);
        }else if (SpaceWorld.health == 1){
            setImage(one);
        }else if (SpaceWorld.health<1){
            setImage(zero);
        }
    }
}

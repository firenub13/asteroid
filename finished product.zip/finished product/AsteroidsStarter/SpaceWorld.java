import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

public class SpaceWorld extends World
{
    //World Constructor
    int cooldown = Greenfoot.getRandomNumber(100)+50;
    int xSide = 0;
    int ySide = 0;
    int side = 0;
    int SufoXside = 0;
    int SufoYside = 0;
    int SufoSide = 0;
    int LufoXside = 0;
    int LufoYside = 0;
    int LufoSide = 0;
    int SufoCooldown = Greenfoot.getRandomNumber(5000)+500;
    int LufoCooldown = Greenfoot.getRandomNumber(2500)+250;
    static int Asteroids = 0;
    static int LargeAsteroids = 0;
    static int score = 0;
    static int health = 3;
    static int speed = 1;
    static int dead = 0;
    static int speeding = 0;
    public SpaceWorld()
    {    
        super(1000, 800, 1,false); 
        addObject(new scoreboard(), 50, 75);
        addObject(new Ship(), 500, 400);
        addObject(new health(), 45, 25);
        
    }
    
    //world act method - add items objects when running
    public void act(){
        if (SufoCooldown>0){
        SufoCooldown--;
    }else{
        SufoSide = Greenfoot.getRandomNumber(2);
        SufoXside = Greenfoot.getRandomNumber(2);
        SufoYside = Greenfoot.getRandomNumber(2);
        if (SufoSide==0){
        if (SufoXside==0){
            addObject(new UFOsmall(), -39, Greenfoot.getRandomNumber(800));
        }else{
            addObject(new UFOsmall(), 1039, Greenfoot.getRandomNumber(800));
        }
        }else{
        if (SufoYside==0){
        addObject(new UFOsmall(), Greenfoot.getRandomNumber(1000), -39);
        }else{
            addObject(new UFOsmall(), Greenfoot.getRandomNumber(1000), 839);
        }
        }
        SufoCooldown = Greenfoot.getRandomNumber(5000)+500;
        }
        
        if (LufoCooldown>0){
        LufoCooldown--;
    }else{
        LufoSide = Greenfoot.getRandomNumber(2);
        LufoXside = Greenfoot.getRandomNumber(2);
        LufoYside = Greenfoot.getRandomNumber(2);
        if (LufoSide==0){
        if (LufoXside==0){
            addObject(new UFObig(), -39, Greenfoot.getRandomNumber(800));
        }else{
            addObject(new UFObig(), 1039, Greenfoot.getRandomNumber(800));
        }
        }else{
        if (SufoYside==0){
        addObject(new UFObig(), Greenfoot.getRandomNumber(1000), -39);
        }else{
            addObject(new UFObig(), Greenfoot.getRandomNumber(1000), 839);
        }
        }
        LufoCooldown = Greenfoot.getRandomNumber(2500)+250;
        }
    
        if (cooldown>0){
        cooldown--;
    }else{
        side = Greenfoot.getRandomNumber(2);
        xSide = Greenfoot.getRandomNumber(2);
        ySide = Greenfoot.getRandomNumber(2);
        if (Asteroids < 15 && LargeAsteroids < 4){
            if (side==0){
            if (xSide==0){
                addObject(new AsteroidLarge(), -39, Greenfoot.getRandomNumber(800));
            }else{
                addObject(new AsteroidLarge(), 1039, Greenfoot.getRandomNumber(800));
            }
            }else{
            if (ySide==0){
                addObject(new AsteroidLarge(), Greenfoot.getRandomNumber(1000), -39);
            }else{
                addObject(new AsteroidLarge(), Greenfoot.getRandomNumber(1000), 839);
            }
            }
            LargeAsteroids++;
            Asteroids++;
        }
        cooldown = Greenfoot.getRandomNumber(200)+200;
        }
    }
}
